<?php get_header(); ?>
<?php get_template_part('template-parts/components/component-breadcrumb', null, array('post_id'=>$post->ID)); ?>
<div class="container-fluid">
    <div class="iz-container">
        <?php
        get_template_part('template-parts/single-offer/single-offer-section-1');
        get_template_part('template-parts/single-offer/single-offer-section-2');
        get_template_part('template-parts/single-offer/single-offer-additional');
        ?>
        <section class="container-fluid mb-5">
            <div class="iz-container offer">
                <?php
                $args = array(
                    'title'=>"Skontaktuj się z nami w celu umówienia wizyty",
                    'wrapper_title' => 'h2',
                    'font_weight_title' => 'normal',
                );
                get_template_part('template-parts/components/component-title-subtitle', null, $args);
                ?>
                <div class="text">
                    INSTYTUT ZDROWIA dr Boczarska-Jedynak mieści się przy ulicy Gen. Dąbrowskiego 4 w centrum Oświęcimia
                    w pobliżu Rynku Głównego i mostu Piastowskiego. Od dworca PKP dzieli nas odległość 2km, od dworca
                    autobusowego 2,5km zaś od najbliższego lotniska – Międzynarodowego Portu Lotniczego im. Jana Pawła
                    II Kraków-Balice około 60km. Dogodne położenie Instytutu zapewnia dobry dojazd z takich miast jak:
                    Bieruń, Tychy, Pszczyna, Czechowice-Dziedzice, Kęty, Andrychów, Wadowice, Zator, Chrzanów,
                    Trzebinia, Jaworzno, Libiąż, Chełmek.
                </div>
                <a href="/zarezerwuj-termin/" class="footer__contact-btn mt-5" data-contact-modal>
                    <span class="footer__contact-btn--text">
                        Zarezerwuj termin
                    </span>
                </a>
            </div>
        </section>
        <?php
        get_template_part('template-parts/components/component-offer-slider');
        ?>
    </div>
</div>
<?php get_footer(); ?>