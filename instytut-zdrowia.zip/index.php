<?php get_header(); ?>
<h1 class="my-5 px-5 py-5 text-center">404: Nie znaleziono strony</h1>
<?php get_footer(); ?>