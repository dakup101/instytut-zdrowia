<?php
/* Template Name: Archiwum Oferty */

get_header();
get_template_part('archive-offers');
get_footer();