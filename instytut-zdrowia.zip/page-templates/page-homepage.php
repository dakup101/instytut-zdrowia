<?php
/* Template Name: Strona Główna */
get_header();
get_template_part('template-parts/homepage/homepage-section-1');
get_template_part('template-parts/homepage/homepage-section-2');
get_template_part('template-parts/homepage/homepage-section-3');
get_template_part('template-parts/homepage/homepage-section-4');
get_template_part('template-parts/homepage/homepage-section-5');
get_template_part('template-parts/icons-row');
get_footer();

