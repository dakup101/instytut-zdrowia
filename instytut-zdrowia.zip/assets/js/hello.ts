export default function hello(){
    alert('hello')
}